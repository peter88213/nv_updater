"""An update checker plugin for novelibre.

Requires Python 3.6+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_updater
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

"""
import webbrowser

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_updater', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod



class SubController:

    def initialize_controller(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self.initialize_controller(model, view, controller)



class ServiceBase:

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
import tkinter as tk
from tkinter import ttk

import platform

import calendar

try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
        _ = t.gettext
    except:

        def _(message):
            return message

WEEKDAYS = calendar.day_name
MONTHS = calendar.month_name



class GenericKeys:

    ADD_CHILD = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    ADD_ELEMENT = ('<Control-n>', f'{_("Ctrl")}-N')
    ADD_PARENT = ('<Control-Alt-N>', f'{_("Ctrl")}-Alt-{_("Shift")}-N')
    BACK = ('<Alt-Left>', f'{_("Alt-Left")}')
    CHAPTER_LEVEL = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DELETE = ('<Delete>', _('Del'))
    DETACH_PROPERTIES = ('<Control-Alt-d>', f'{_("Ctrl")}-Alt-D')
    FOLDER = ('<Control-p>', f'{_("Ctrl")}-P')
    FORWARD = ('<Alt-Right>', f'{_("Alt-Right")}')
    LOCK_PROJECT = ('<Control-l>', f'{_("Ctrl")}-L')
    NEXT = ('<Alt-Down>', f'{_("Alt-Down")}')
    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PREVIOUS = ('<Alt-Up>', f'{_("Alt-Up")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    REFRESH_TREE = ('<F5>', 'F5')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    RESTORE_BACKUP = ('<Control-b>', f'{_("Ctrl")}-B')
    RESTORE_STATUS = ('<Escape>', 'Esc')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    TOGGLE_PROPERTIES = ('<Control-Alt-t>', f'{_("Ctrl")}-Alt-T')
    TOGGLE_VIEWER = ('<Control-t>', f'{_("Ctrl")}-T')
    UNLOCK_PROJECT = ('<Control-u>', f'{_("Ctrl")}-U')



class GenericMouse:

    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<Alt-B1-Motion>'
    RIGHT_CLICK = '<Button-3>'


class MacKeys(GenericKeys):

    ADD_CHILD = ('<Command-Alt-n>', 'Cmd-Alt-N')
    ADD_ELEMENT = ('<Command-n>', 'Cmd-N')
    ADD_PARENT = ('<Command-Alt-Shift-N>', 'Cmd-Alt-Shift-N')
    CHAPTER_LEVEL = ('<Command-Alt-c>', 'Cmd-Alt-C')
    COPY = ('<Command-c>', 'Cmd-C')
    CUT = ('<Command-x>', 'Cmd-X')
    DETACH_PROPERTIES = ('<Command-Alt-d>', 'Cmd-Alt-D')
    FOLDER = ('<Command-p>', 'Cmd-P')
    LOCK_PROJECT = ('<Command-l>', 'Cmd-L')
    OPEN_PROJECT = ('<Command-o>', 'Cmd-O')
    PASTE = ('<Command-v>', 'Cmd-V')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    RELOAD_PROJECT = ('<Command-r>', 'Cmd-R')
    RESTORE_BACKUP = ('<Command-b>', 'Cmd-B')
    SAVE_AS = ('<Command-S>', 'Cmd-Shift-S')
    SAVE_PROJECT = ('<Command-s>', 'Cmd-S')
    TOGGLE_PROPERTIES = ('<Command-Alt-t>', 'Cmd-Alt-T')
    TOGGLE_VIEWER = ('<Command-t>', 'Cmd-T')
    UNLOCK_PROJECT = ('<Command-u>', 'Cmd-U')


class MacMouse(GenericMouse):

    RIGHT_CLICK = '<Button-2>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()

from abc import abstractmethod



class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()

import configparser
from urllib.request import urlopen




class NvHelp:

    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/'

    @classmethod
    def open_help_page(cls, page):
        webbrowser.open(f'{cls.HELP_URL}{page}')

from datetime import date
from pathlib import Path

prefs = {}
launchers = {}

HOME_URL = 'https://github.com/peter88213/novelibre/'

HOME_DIR = str(Path.home()).replace('\\', '/')
INSTALL_DIR = f'{HOME_DIR}/.novx'
PROGRAM_DIR = os.path.dirname(sys.argv[0])
if not PROGRAM_DIR:
    PROGRAM_DIR = '.'
USER_STYLES_DIR = f'{INSTALL_DIR}/styles'
USER_STYLES_XML = f'{USER_STYLES_DIR}/styles.xml'


def datestr(isoDate):
    if prefs['localize_date']:
        return date.fromisoformat(isoDate).strftime("%x")
    else:
        return isoDate


def get_section_date_str(section):
    if prefs['localize_date']:
        return section.localeDate
    else:
        return section.date


def to_string(text):
    if text is None:
        return ''

    return str(text)



class UpdateManagerCtrl(SubController):

    def initialize_controller(self, model, view, controller):
        super().initialize_controller(model, view, controller)
        self.downloadUrls = {}
        self.download = False

    def build_module_list(self):
        repoName = 'novelibre'
        self.downloadUrls[repoName] = None
        appValues = [
            repoName,
            f'{self._ctrl.plugins.majorVersion}.{self._ctrl.plugins.minorVersion}.{self._ctrl.plugins.patchlevel}',
            f"{_('wait')} ...",
            ]
        self.repoList.insert('', 'end', 'novelibre', values=appValues)

        for repoName in self._ctrl.plugins:
            if self._ctrl.plugins[repoName].isRejected:
                continue

            self.downloadUrls[repoName] = None
            nodeTags = []
            try:
                installedVersion = self._ctrl.plugins[repoName].VERSION
            except AttributeError:
                installedVersion = _('unknown')
            latestVersion = f"{_('wait')} ..."
            columns = [repoName, installedVersion, latestVersion]
            if not self._ctrl.plugins[repoName].isActive:
                nodeTags.append('inactive')
            self.repoList.insert('', 'end', repoName, values=columns, tags=tuple(nodeTags))
        self.update()

    def check_repos(self):
        self.output(f"{_('Looking for updates')}...")
        found = False

        repoName = 'novelibre'
        try:
            majorVersion, minorVersion, patchlevel, downloadUrl = self._get_version_info(repoName)
        except:
            latestStr = _('unknown')
        else:
            latest = (majorVersion, minorVersion, patchlevel)
            latestStr = f'{majorVersion}.{minorVersion}.{patchlevel}'
            current = (self._ctrl.plugins.majorVersion, self._ctrl.plugins.minorVersion, self._ctrl.plugins.patchlevel)
            currentStr = f'{self._ctrl.plugins.majorVersion}.{self._ctrl.plugins.minorVersion}.{self._ctrl.plugins.patchlevel}'
            if self._update_available(latest, current):
                self.downloadUrls[repoName] = downloadUrl
                tags = ('outdated')
                found = True
            else:
                tags = ()
        self._refresh_display(repoName, [repoName, currentStr, latestStr], tags=tags)

        for repoName in self._ctrl.plugins:
            if self._ctrl.plugins[repoName].isRejected:
                continue

            try:
                majorVersion, minorVersion, patchlevel = self._ctrl.plugins[repoName].VERSION.split('.')
                current = (int(majorVersion), int(minorVersion), int(patchlevel))
                currentStr = f'{majorVersion}.{minorVersion}.{patchlevel}'
            except:
                current = (0, 0, 0)
                currentStr = _('unknown')
            try:
                majorVersion, minorVersion, patchlevel, downloadUrl = self._get_version_info(repoName)
                latest = (majorVersion, minorVersion, patchlevel)
                latestStr = f'{majorVersion}.{minorVersion}.{patchlevel}'
            except:
                latestStr = _('unknown')
                tags = ()
            else:
                if self._update_available(latest, current):
                    self.downloadUrls[repoName] = downloadUrl
                    tags = ('outdated')
                    found = True
                else:
                    tags = ()
            self._refresh_display(repoName, [repoName, currentStr, latestStr], tags=tags)
        if not found:
            self.output(f"{_('No updates available')}.")
        else:
            self.output(f"{_('Finished')}.")
        if False:
            self._ui.show_info(f"{_('Please restart novelibre after installing updates')}.", title=_('Check for updates'))

    def on_select_module(self, event):
        repoName = self.repoList.selection()[0]
        homeButtonState = 'disabled'
        updateButtonState = 'disabled'
        if repoName:
            if  repoName == 'novelibre':
                homeButtonState = 'normal'
                updateButtonState = 'normal'
            else:
                try:
                    if self._ctrl.plugins[repoName].URL:
                        homeButtonState = 'normal'
                except:
                    pass
                try:
                    if self.downloadUrls[repoName] is not None:
                        updateButtonState = 'normal'
                except:
                    pass
        self.homeButton.configure(state=homeButtonState)
        self.updateButton.configure(state=updateButtonState)

    def on_quit(self):
        if self.download:
            self._ui.show_info(f"{_('Please restart novelibre after installing updates')}.", title=_('Check for updates'))
        self.destroy()

    def open_help(self, event=None):
        NvHelp.open_help_page(f"tools_menu.html#{_('Check for updates').lower()}")

    def open_homepage(self, event=None):
        repoName = self.repoList.selection()[0]
        if repoName:
            if repoName == 'novelibre':
                webbrowser.open(HOME_URL)
                return

            try:
                url = self._ctrl.plugins[repoName].URL
                if url:
                    webbrowser.open(url)
            except:
                pass

    def update_module(self, event=None):
        repoName = self.repoList.selection()[0]
        if self.downloadUrls[repoName] is None:
            return

        webbrowser.open(self.downloadUrls[repoName])
        self.repoList.item(repoName, tags=('updated'))
        self.download = True

    def _get_version_info(self, repoName):
        if repoName == 'novelibre':
            repoUrl = 'https://github.com/peter88213/novelibre'
        else:
            repoUrl = self._ctrl.plugins[repoName].URL
        versionUrl = f'{repoUrl}/raw/main/VERSION'
        data = urlopen(versionUrl)
        versionInfo = data.read().decode('utf-8')
        config = configparser.ConfigParser()
        config.read_string(versionInfo)
        downloadUrl = config['LATEST']['download_link']
        version = config['LATEST']['version']
        majorVersion, minorVersion, patchlevel = version.split('.')
        return int(majorVersion), int(minorVersion), int(patchlevel), downloadUrl

    def _refresh_display(self, repoName, values, tags=()):
        self.repoList.item(repoName, values=values, tags=tags)
        self.update()

    def _update_available(self, latest, current):
        if latest[0] > current[0]:
            return True

        if latest[0] == current[0]:
            if latest[1] > current[1]:
                return True

            if latest[1] == current[1]:
                if latest[2] > current[2]:
                    return True

        return False




class NvupdaterHelp:

    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_updater/'

    @classmethod
    def open_help_page(cls, event=None):
        webbrowser.open(cls.HELP_URL)



class UpdateManagerDialog(ModalDialog, UpdateManagerCtrl):

    MIN_HEIGHT = 450

    def __init__(self, model, view, controller, **kw):
        super().__init__(view, **kw)
        self.minsize(1, self.MIN_HEIGHT)
        self.initialize_controller(model, view, controller)

        self.title(f'{_("Check for updates")} - novelibre 5.1.3')

        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        columns = 'Module', 'Installed version', 'Latest version'
        self.repoList = ttk.Treeview(self, columns=columns, show='headings', selectmode='browse')


        self.repoList.pack(fill='both', expand=True)
        self.repoList.bind('<<TreeviewSelect>>', self.on_select_module)
        self.repoList.tag_configure('outdated', foreground='red')
        self.repoList.tag_configure('updated', foreground='green')
        self.repoList.tag_configure('inactive', foreground='gray')

        self.repoList.column('Module', width=150, minwidth=120, stretch=False)
        self.repoList.heading('Module', text=_('Module'), anchor='w')
        self.repoList.column('Installed version', width=100, minwidth=100, stretch=False)
        self.repoList.heading('Installed version', text=_('Installed version'), anchor='w')
        self.repoList.column('Latest version', width=100, minwidth=100, stretch=False)
        self.repoList.heading('Latest version', text=_('Latest version'), anchor='w')

        self.messagingArea = tk.Label(self, fg='white', bg='green')
        self.messagingArea.pack(fill='x')

        self._footer = ttk.Frame(self)
        self._footer.pack(fill='both', expand=False)

        self.updateButton = ttk.Button(
            self._footer,
            text=_('Update'),
            command=self.update_module,
            state='disabled'
            )
        self.updateButton.pack(padx=5, pady=5, side='left')

        self.homeButton = ttk.Button(
            self._footer,
            text=_('Home page'),
            command=self.open_homepage,
            state='disabled'
            )
        self.homeButton.pack(padx=5, pady=5, side='left')

        ttk.Button(
            self._footer,
            text=_('Close'),
            command=self.on_quit
            ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self._footer,
            text=_('Online help'),
            command=NvupdaterHelp.open_help_page
            ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], NvupdaterHelp.open_help_page)
        self.repoList.bind('<Double-1>', self.update_module)

        self.build_module_list()

    def output(self, text):
        try:
            self.messagingArea.configure(text=text)
        except:
            pass



class UpdateService(ServiceBase):

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)

    def check_for_updates(self):
        self.updaterDialog = UpdateManagerDialog(self._mdl, self._ui, self._ctrl)
        self.updaterDialog.check_repos()



class Plugin(PluginBase):
    VERSION = '5.1.3'
    API_VERSION = '5.0'
    DESCRIPTION = 'Update checker'
    URL = 'https://github.com/peter88213/nv_updater'

    def install(self, model, view, controller):
        """Install the plugin and extend the novelibre user interface.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.updateManager = UpdateService(model, view, controller)

        self._ui.helpMenu.add_command(label=_('Update checker Online help'), command=self.open_help)

        self._ui.toolsMenu.add_command(label=_('Check for updates'), command=self.check_for_updates)

    def check_for_updates(self):
        self.updateManager.check_for_updates()

    def open_help(self, event=None):
        webbrowser.open(self.HELP_URL)


"""An update checker plugin for novelibre.

Requires Python 3.7+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_updater
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

"""
from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon

HELP_PAGE = 'nv_updater'

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_updater',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message



class ServiceBase:

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller


def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

import configparser
from tkinter import ttk
from urllib.request import urlopen
import webbrowser

import platform


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message



class GenericKeys:

    ADD_CHILD = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    ADD_ELEMENT = ('<Control-n>', f'{_("Ctrl")}-N')
    ADD_PARENT = ('<Control-Alt-N>', f'{_("Ctrl")}-Alt-{_("Shift")}-N')
    BACK = ('<Alt-Left>', f'Alt-{_("Left")}')
    CHAPTER_LEVEL = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DELETE = ('<Delete>', _('Del'))
    DETACH_PROPERTIES = ('<Control-Alt-d>', f'{_("Ctrl")}-Alt-D')
    FOLDER = ('<Control-p>', f'{_("Ctrl")}-P')
    FORWARD = ('<Alt-Right>', f'Alt-{_("Right")}')
    LOCK_PROJECT = ('<Control-l>', f'{_("Ctrl")}-L')
    NEXT = ('<Alt-Down>', f'Alt-{_("Down")}')
    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PREVIOUS = ('<Alt-Up>', f'Alt-{_("Up")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    REFRESH_TREE = ('<F5>', 'F5')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    RESTORE_BACKUP = ('<Control-b>', f'{_("Ctrl")}-B')
    RESTORE_STATUS = ('<Escape>', 'Esc')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    TOGGLE_PROPERTIES = ('<Control-Alt-t>', f'{_("Ctrl")}-Alt-T')
    TOGGLE_VIEWER = ('<Control-t>', f'{_("Ctrl")}-T')
    UNDO = ('<Control-z>', f'{_("Ctrl")}-Z')
    UNLOCK_PROJECT = ('<Control-u>', f'{_("Ctrl")}-U')



class GenericMouse:

    CHOOSE_COLOR = '<Button-1>'
    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<B1-Motion>'
    RESET_COLOR = '<Shift-Button-1>'
    RIGHT_CLICK = '<Button-3>'


class MacKeys(GenericKeys):

    ADD_CHILD = ('<Command-Option-n>', 'Cmd-Option-N')
    ADD_ELEMENT = ('<Command-n>', 'Cmd-N')
    ADD_PARENT = ('<Command-Option-N>', 'Cmd-Option-Shift-N')
    BACK = ('<Option-Left>', f'Option-{_("Left")}')
    CHAPTER_LEVEL = ('<Command-Option-c>', 'Cmd-Option-C')
    COPY = ('<Command-c>', 'Cmd-C')
    CUT = ('<Command-x>', 'Cmd-X')
    DETACH_PROPERTIES = ('<Command-Option-d>', 'Cmd-Option-D')
    FOLDER = ('<Command-p>', 'Cmd-P')
    FORWARD = ('<Option-Right>', f'Option-{_("Right")}')
    LOCK_PROJECT = ('<Command-l>', 'Cmd-L')
    NEXT = ('<Option-Down>', f'Option-{_("Down")}')
    OPEN_PROJECT = ('<Command-o>', 'Cmd-O')
    PASTE = ('<Command-v>', 'Cmd-V')
    PREVIOUS = ('<Option-Up>', f'Option-{_("Up")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    RELOAD_PROJECT = ('<Command-r>', 'Cmd-R')
    RESTORE_BACKUP = ('<Command-b>', 'Cmd-B')
    SAVE_AS = ('<Command-S>', 'Cmd-Shift-S')
    SAVE_PROJECT = ('<Command-s>', 'Cmd-S')
    TOGGLE_PROPERTIES = ('<Command-Option-t>', 'Cmd-Option-T')
    TOGGLE_VIEWER = ('<Command-t>', 'Cmd-T')
    UNDO = ('<Command-z>', 'Cmd-Z')
    UNLOCK_PROJECT = ('<Command-u>', 'Cmd-U')



class MacMouse(GenericMouse):

    RIGHT_CLICK = '<Button-2>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()

from abc import abstractmethod



class ModalDialog(tk.Toplevel):
    OFFSET = 300
    RESIZABLE = False

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        if not self.RESIZABLE:
            self.withdraw()

            self.wm_resizable(False, False)
            if platform.system() == 'Windows':
                self.attributes('-toolwindow', True)
            self.update()
            self.deiconify()
        self.wait_visibility()
        self.grab_set()
        self.focus()
        self.wm_attributes('-topmost', True)



class UpdateManager(ModalDialog, SubController):

    MIN_HEIGHT = 500

    def __init__(self, model, view, controller, **kw):

        def open_help_page(event=None):
            self._ctrl.open_help(page=HELP_PAGE)

        super().__init__(view, **kw)
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        self.title(f'{_("Check for updates")} - novelibre 5.4.4')
        self.minsize(1, self.MIN_HEIGHT)
        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        self._downloadUrls = {}
        self._download = False
        self._stopSearching = False

        treeWindow = ttk.Frame(self)
        treeWindow.pack(fill='both', expand=True)

        columns = 'Component', 'Installed version', 'Latest version'
        self._repoList = ttk.Treeview(
            treeWindow,
            columns=columns,
            show='headings',
            selectmode='browse',
        )

        scrollY = ttk.Scrollbar(
           treeWindow,
           orient='vertical',
           command=self._repoList.yview,
        )
        self._repoList.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')

        self._repoList.pack(fill='both', expand=True)
        self._repoList.bind('<<TreeviewSelect>>', self._on_select_plugin)
        self._repoList.tag_configure('outdated', foreground='red')
        self._repoList.tag_configure('updated', foreground='blue')
        self._repoList.tag_configure('inactive', foreground='gray')

        self._repoList.column(
            'Component',
            width=150,
            minwidth=120,
            stretch=False,
        )
        self._repoList.heading(
            'Component',
            text=_('Component'),
            anchor='w',
        )
        self._repoList.column(
            'Installed version',
            width=120,
            minwidth=100,
            stretch=False,
        )
        self._repoList.heading(
            'Installed version',
            text=_('Installed version'),
            anchor='w',
        )
        self._repoList.column(
            'Latest version',
            width=120,
            minwidth=100,
            stretch=False,
        )
        self._repoList.heading(
            'Latest version',
            text=_('Latest version'),
            anchor='w',
        )

        self._messagingArea = tk.Label(self, fg='white', bg='green')
        self._messagingArea.pack(fill='x')

        footer = tk.Frame(self)
        footer.pack(fill='both', expand=False)

        self._updateButton = ttk.Button(
            footer,
            text=_('Update'),
            command=self._update_module,
            state='disabled',
        )
        self._updateButton.pack(padx=5, pady=5, side='left')

        self._homeButton = ttk.Button(
            footer,
            text=_('Home page'),
            command=self._open_homepage,
            state='disabled',
        )
        self._homeButton.pack(padx=5, pady=5, side='left')

        ttk.Button(
            footer,
            text=_('Close'),
            command=self.on_quit,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            footer,
            text=_('Help'),
            command=open_help_page,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], open_help_page)
        self._repoList.bind('<Double-1>', self._update_module)

        self._build_module_list()

    def check_repos(self):
        self._output(f"{_('Looking for updates')}...")
        found = False

        repoName = 'novelibre'
        current = (
            self._ctrl.plugins.majorVersion,
            self._ctrl.plugins.minorVersion,
            self._ctrl.plugins.patchlevel,
        )
        currentStr = (
            f'{self._ctrl.plugins.majorVersion}.'
            f'{self._ctrl.plugins.minorVersion}.'
            f'{self._ctrl.plugins.patchlevel}'
        )
        try:
            (majorVersion,
             minorVersion,
             patchlevel,
             downloadUrl) = self._get_remote_data(repoName)
        except:
            latestStr = _('unknown')
            tags = ()
        else:
            latest = (majorVersion, minorVersion, patchlevel)
            latestStr = f'{majorVersion}.{minorVersion}.{patchlevel}'
            if self._update_available(latest, current):
                self._downloadUrls[repoName] = downloadUrl
                tags = ('outdated')
                found = True
            else:
                tags = ()
        self._refresh_display(
            repoName,
            [repoName, currentStr, latestStr],
            tags=tags,
        )

        for repoName in self._ctrl.plugins:
            if self._stopSearching:
                return

            if self._ctrl.plugins[repoName].isRejected:
                continue

            try:
                (majorVersion,
                 minorVersion,
                 patchlevel) = self._ctrl.plugins[repoName].VERSION.split('.')
                current = (
                    int(majorVersion),
                    int(minorVersion),
                    int(patchlevel),
                )
                currentStr = f'{majorVersion}.{minorVersion}.{patchlevel}'
            except:
                current = (0, 0, 0)
                currentStr = _('unknown')
            try:
                (majorVersion,
                 minorVersion,
                 patchlevel,
                 downloadUrl) = self._get_remote_data(repoName)
                latest = (majorVersion, minorVersion, patchlevel)
                latestStr = f'{majorVersion}.{minorVersion}.{patchlevel}'
            except:
                latestStr = _('unknown')
                tags = ()
            else:
                if self._update_available(latest, current):
                    self._downloadUrls[repoName] = downloadUrl
                    tags = ('outdated')
                    found = True
                else:
                    tags = ()
            self._refresh_display(
                repoName,
                [repoName, currentStr, latestStr],
                tags=tags,
                )
        if not found:
            self._output(f"{_('No updates available')}.")
        else:
            self._output(f"{_('Finished')}.")

    def on_quit(self):
        self._stopSearching = True
        if self._download:
            self._ui.show_info(
                message=_('Please restart novelibre after installing updates'),
                detail=f"{_('Outdated components remain active until next start')}.",
                title=_('Check for updates'),
                parent=self,
            )
        self.destroy()

    def _build_module_list(self):
        repoName = 'novelibre'
        self._downloadUrls[repoName] = None
        appValues = [
            repoName,
            (
                f'{self._ctrl.plugins.majorVersion}.'
                f'{self._ctrl.plugins.minorVersion}.'
                f'{self._ctrl.plugins.patchlevel}'
            ),
            f"{_('wait')} ...",
            ]
        self._repoList.insert('', 'end', 'novelibre', values=appValues)

        for repoName in self._ctrl.plugins:
            if self._ctrl.plugins[repoName].isRejected:
                continue

            self._downloadUrls[repoName] = None
            nodeTags = []
            try:
                installedVersion = self._ctrl.plugins[repoName].VERSION
            except AttributeError:
                installedVersion = _('unknown')
            latestVersion = f"{_('wait')} ..."
            columns = [repoName, installedVersion, latestVersion]
            if not self._ctrl.plugins[repoName].isActive:
                nodeTags.append('inactive')
            self._repoList.insert(
                '', 'end',
                repoName,
                values=columns,
                tags=tuple(nodeTags),
            )
        self.update()

    def _get_remote_data(self, repoName):
        if repoName == 'novelibre':
            repoUrl = 'https://github.com/peter88213/novelibre'
        else:
            repoUrl = self._ctrl.plugins[repoName].URL
        versionUrl = f'{repoUrl}/raw/main/VERSION'
        data = urlopen(versionUrl)
        versionInfo = data.read().decode('utf-8')
        config = configparser.ConfigParser()
        config.read_string(versionInfo)
        downloadUrl = config['LATEST']['download_link']
        version = config['LATEST']['version']
        majorVersion, minorVersion, patchlevel = version.split('.')
        return (
            int(majorVersion),
            int(minorVersion),
            int(patchlevel),
            downloadUrl
        )

    def _on_select_plugin(self, event):
        repoName = self._repoList.selection()[0]
        homeButtonState = 'disabled'
        updateButtonState = 'disabled'
        if repoName:
            if  repoName == 'novelibre':
                homeButtonState = 'normal'
                updateButtonState = 'normal'
            else:
                try:
                    if self._ctrl.plugins[repoName].URL:
                        homeButtonState = 'normal'
                except:
                    pass
                try:
                    if self._downloadUrls[repoName] is not None:
                        updateButtonState = 'normal'
                except:
                    pass
        self._homeButton.configure(state=homeButtonState)
        self._updateButton.configure(state=updateButtonState)

    def _open_homepage(self, event=None):
        repoName = self._repoList.selection()[0]
        if repoName:
            if repoName == 'novelibre':
                webbrowser.open(self._mdl.nvService.get_novelibre_home_url())
                return

            try:
                url = self._ctrl.plugins[repoName].URL
                if url:
                    webbrowser.open(url)
            except:
                pass

    def _output(self, text):
        try:
            self._messagingArea.configure(text=text)
        except:
            pass

    def _refresh_display(self, repoName, values, tags=()):
        try:
            self._repoList.item(repoName, values=values, tags=tags)
            self.update()
        except:
            pass

    def _update_available(self, latest, current):
        if latest[0] > current[0]:
            return True

        if latest[0] == current[0]:
            if latest[1] > current[1]:
                return True

            if latest[1] == current[1]:
                if latest[2] > current[2]:
                    return True

        return False

    def _update_module(self, event=None):
        repoName = self._repoList.selection()[0]
        if self._downloadUrls[repoName] is None:
            return

        webbrowser.open(self._downloadUrls[repoName])
        self._repoList.item(repoName, tags=('updated'))
        self._download = True



class UpdateService(ServiceBase):

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)

    def check_for_updates(self):
        self.updaterDialog = UpdateManager(self._mdl, self._ui, self._ctrl)
        set_icon(self.updaterDialog, icon='update', default=False)
        self.updaterDialog.check_repos()



class Plugin(PluginBase):
    VERSION = '5.4.4'
    API_VERSION = '5.63'
    DESCRIPTION = 'Update checker'
    URL = 'https://github.com/peter88213/nv_updater'
    HELP_PAGE = HELP_PAGE

    def install(self, model, view, controller):
        """Install the plugin at runtime.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.updateService = UpdateService(model, view, controller)
        self._icon = self._get_icon('update.png')


        label = _('Check for updates')
        self._ui.toolsMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self.updateService.check_for_updates,
        )

        self._add_help_menu_entry(_('Update checker plugin help'))

